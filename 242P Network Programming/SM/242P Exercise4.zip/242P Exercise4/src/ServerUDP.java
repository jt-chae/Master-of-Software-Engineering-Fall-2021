import java.net.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

//https://blog.csdn.net/shulianghan/article/details/100175768
//https://stackoverflow.com/questions/31494335/how-to-tranfer-large-file-from-server-to-client-using-udp
//Example 12.3 Page405， Example 12-5. page412，Example 12-6. page414
public class ServerUDP {
    static final int port = 3737; //0-1023-49151-65535

    //called by getFile() method in response to an "INDEX" command
    private static void sendIndex(File directory, PrintWriter response) throws Exception {
        String[] fileList = directory.list();
        String daytime = new Date().toString();
        byte[] data = daytime.getBytes("US-ASCII");
        DatagramPacket response = new DatagramPacket(data, data.length, request.getAddress(), request.getPort());
        socket.send(response);
        audit.info(daytime + " " + request.getAddress());
        for (int i = 0; i < fileList.length; i++)
            outStream.println(fileList[i]);
        outStream.close();
        if (outStream.checkError())
            throw new Exception("Error while transmitting data.");
    }

    //called by getFile() command in response to "GET <fileName>"
    private static void sendFile(String fileName, File directory, PrintWriter outStream)
            throws Exception {
        byte[] data = daytime.getBytes("US-ASCII");
        DatagramPacket response = new DatagramPacket(data, data.length, request.getAddress(), request.getPort());
        socket.send(response);
        audit.info(daytime + " " + request.getAddress());
        File file = new File(directory,fileName);
        if ( (! file.exists()) || file.isDirectory() ) { //If the file doesn't exist or a directory
            outStream.println("ERROR"); //send the message "ERROR".
        }
        else {
            outStream.println("OK"); //Otherwise, send the message "OK"
            BufferedReader fileIn = new BufferedReader( new FileReader(file) );
            while (true) {
                // Read and send lines from the file until an end-of-file is encountered.
                String line = fileIn.readLine();
                if (line == null)
                    break;
                outStream.println(line); //send the contents of the file.
            }
        }
        outStream.flush();
        outStream.close();
        if (outStream.checkError())
            throw new Exception("Error while transmitting data.");
    }

    public static void main(String[] args) {
        File directory;        // directory of files
        Scanner inStream;                                     // reading data from the client.
        PrintWriter outStream;                                // transmitting data to the client.
        String command = "Ready for getting command";
        DatagramSocket socket; // input from command.

        if (args.length == 0) { // if command-line argument=0，print format
            System.out.println("Format:  java ServerTCP.java <directory>");
            return;
        }

        directory = new File(args[0]); //Get the directory name from the command line and make it a file object
        if ( ! directory.exists() ) {
            System.out.println("This directory does not exist.");
            return;
        }
        if (! directory.isDirectory() ) {
            System.out.println("This file is not a directory.");
            return;
        }

        //blocks indefinitely until a UDP packet arrives port. When it does, Java fills the byte array with data and the receive() method returns.
            try {
                socket = new DatagramSocket(port);
                System.out.println("Listening on port " + port);

        while (true){
            try{
                DatagramPacket request = new DatagramPacket(new byte[1024], 1024);
                socket.receive(request);


                request = new Scanner( socket.getInputStream() );
                response = new PrintWriter( connection.getOutputStream() );
                command = inStream.nextLine();
                if (command.equalsIgnoreCase("index")) { //The command can be the string "index".
                    sendIndex(directory, outStream); //responds by sending a list of names of all the files that are available on the server.
                }
                else if (command.toLowerCase().startsWith("get")){ //the command can be of the form "get <file>".
                    String fileName = command.substring(3).trim(); //get filename from command
                    sendFile(fileName, directory, outStream);
                }
                else {
                    outStream.println("Input is not valid.");
                    outStream.flush();
                }
                System.out.println("OK    " + connection.getInetAddress()
                        + " " + command);
            }
            catch (Exception e) {
                System.out.println("ERROR " + connection.getInetAddress()
                        + " " + command + " " + e);
            }
            }
        }
    }
        catch (Exception e) {
            System.out.println("Server shut down unexpectedly.");
            System.out.println("Error:  " + e);
        } // The server runs until the program is terminated, ex.CONTROL-C.
    }
} // end main()